# Vault plugin

Note: this plugin is deprecated. Use the [official autocompletion](https://www.vaultproject.io/docs/commands/index.html#autocompletion) instead.

-------

Adds autocomplete options for all [vault](https://www.vaultproject.io) commands.

To use it, add `vault` to the plugins array in your zshrc file:

```zsh
plugins=(... vault)
```

Crafted with <3 by Valentin Bud ([@valentinbud](https://twitter.com/valentinbud))
